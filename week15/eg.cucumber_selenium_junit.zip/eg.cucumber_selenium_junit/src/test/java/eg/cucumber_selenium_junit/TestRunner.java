package eg.cucumber_selenium_junit;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(publish=true,
//plugin= {"pretty"})
plugin = {"html:target/cucumber-html-report","json:target/cucumber-json-report.json"})
//above plugin option generate Test report in HTML and Json format in target folder
public class TestRunner {

}
