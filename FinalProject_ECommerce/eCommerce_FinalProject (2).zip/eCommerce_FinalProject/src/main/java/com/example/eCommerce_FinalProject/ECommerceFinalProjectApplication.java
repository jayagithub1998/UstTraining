package com.example.eCommerce_FinalProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceFinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommerceFinalProjectApplication.class, args);
	}

}
