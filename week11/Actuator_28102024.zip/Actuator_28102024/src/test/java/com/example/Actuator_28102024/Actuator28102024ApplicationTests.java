package com.example.Actuator_28102024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Actuator28102024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
