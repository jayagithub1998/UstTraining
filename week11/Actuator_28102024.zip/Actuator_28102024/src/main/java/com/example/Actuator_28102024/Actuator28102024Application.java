package com.example.Actuator_28102024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Actuator28102024Application {

	public static void main(String[] args) {
		SpringApplication.run(Actuator28102024Application.class, args);
	}

}
