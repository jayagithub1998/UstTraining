package com.example.onetomany08102024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Onetomany08102024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
